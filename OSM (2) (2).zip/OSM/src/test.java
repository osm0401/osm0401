import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JButton;
import java.awt.BorderLayout;
import java.awt.GridLayout;
import java.awt.Image;

import javax.swing.JTextField;
import javax.swing.JLabel;
import javax.swing.JPasswordField;
import java.awt.Button;
import java.awt.event.ActionListener;
import java.awt.image.ImageObserver;
import java.awt.image.ImageProducer;
import java.sql.Connection;
import java.sql.SQLException;
import java.awt.event.ActionEvent;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import java.awt.Label;
import java.awt.Panel;
import java.awt.Font;
import java.awt.Graphics;

import javax.swing.SwingConstants;
import javax.swing.AbstractAction;
import javax.swing.Action;
import java.sql.*;
public class test extends JFrame {
	private Sample db = new Sample();
	private host hos = new host();
	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField textField;
	private final Action action = new SwingAction();
	private final Action action_1 = new SwingAction_1();
	private test_client client = new test_client();
	private JTextField passss;
	private chating ch = new chating();
	static test frame = new test();

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					
					try {
						frame.setVisible(true);
					} catch (Exception e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	public test() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 751, 530);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setToolTipText("");
		panel.setBounds(149, 5, 416, 205);
		contentPane.add(panel);
		panel.setLayout(null);
		
		Font oms = new Font("Knewave",Font.ITALIC,20);
		
		JLabel lblNewLabel_1 = new JLabel("OSM");
		lblNewLabel_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1.setFont(new Font("Knewave", Font.PLAIN, 99));
		lblNewLabel_1.setBounds(0, 0, 416, 205);
		panel.add(lblNewLabel_1);
		
		textField = new JTextField();
		textField.setBounds(343, 260, 146, 35);
		contentPane.add(textField);
		textField.setColumns(10);
		
		JLabel lblNewLabel = new JLabel("I D : ");
		lblNewLabel.setBounds(254, 265, 81, 25);
		contentPane.add(lblNewLabel);
		
		JLabel lblPassword = new JLabel("PASSWORD:");
		lblPassword.setBounds(254, 310, 81, 25);
		contentPane.add(lblPassword);
		
		JButton btnNewButton = new JButton("CHECK");
		btnNewButton.setAction(action);
		btnNewButton.setFont(new Font("배달의민족 주아", Font.PLAIN, 20));
		btnNewButton.setBounds(242, 397, 251, 35);
		contentPane.add(btnNewButton);
		
		JLabel lblNewLabel_2 = new JLabel("log in  page");
		lblNewLabel_2.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_2.setFont(new Font("배달의민족 주아", Font.PLAIN, 40));
		lblNewLabel_2.setBounds(251, 206, 241, 49);
		contentPane.add(lblNewLabel_2);
		
		JButton check = new JButton("check");
		check.setAction(action_1);
		check.setFont(new Font("배달의민족 주아", Font.PLAIN, 20));
		check.setBounds(242, 350, 251, 35);
		contentPane.add(check);
		
		passss = new JTextField();
		passss.setBounds(343, 305, 146, 35);
		contentPane.add(passss);
		passss.setColumns(10);
	}
	private class SwingAction extends AbstractAction {
		public SwingAction() {
			putValue(NAME, "sgin up");
			putValue(SHORT_DESCRIPTION, "Some short description");
		}
		public void actionPerformed(ActionEvent e) {
			System.out.println("Hello");
			new signUp(); ///   (JFrame)malloc(sizeof(signUp()))
	
		}
		
	}
	private class SwingAction_1 extends AbstractAction {
		public SwingAction_1() {
			putValue(NAME, "check");
			putValue(SHORT_DESCRIPTION, "Some short description");
		}
		public void actionPerformed(ActionEvent e) {
	    		try {
					Connection conn = db.getConnection();
					if(db.log_in(textField.getText(),passss.getText()))
					{
						frame.setVisible(false);
						//client.start();
						//ch.main(null);
						
					}
					else
						System.out.printf("에잉 쯔쯔");
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
	    		
	    	
		}
	}
}
