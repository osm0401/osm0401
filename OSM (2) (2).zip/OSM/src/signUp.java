import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JRadioButton;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.ButtonGroup;
import javax.swing.JEditorPane;
import javax.swing.JButton;
import javax.swing.AbstractAction;
import java.awt.event.ActionEvent;
import javax.swing.Action;
import java.awt.event.ActionListener;

public class signUp extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField name;
	private JTextField logn;
	private JTextField pass;
	private JTextField live;
	private JTextField email;
	private JTextField nick;
	private final Action action = new SwingAction();
	private Sample db = new Sample();

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					signUp frame = new signUp();
					
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public signUp() {
		setBounds(100, 100, 413, 650);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setVisible(true);
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("닉네임");
		lblNewLabel.setFont(new Font("배달의민족 주아", Font.PLAIN, 30));
		lblNewLabel.setBounds(12, 118, 159, 54);
		contentPane.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("이름");
		lblNewLabel_1.setFont(new Font("배달의민족 주아", Font.PLAIN, 30));
		lblNewLabel_1.setBounds(12, 182, 159, 54);
		contentPane.add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel("로그인 ID");
		lblNewLabel_2.setFont(new Font("배달의민족 주아", Font.PLAIN, 30));
		lblNewLabel_2.setBounds(12, 246, 159, 54);
		contentPane.add(lblNewLabel_2);
		
		JLabel lblNewLabel_3 = new JLabel("PASSWORD");
		lblNewLabel_3.setFont(new Font("배달의민족 주아", Font.PLAIN, 30));
		lblNewLabel_3.setBounds(12, 310, 159, 54);
		contentPane.add(lblNewLabel_3);
		
		JLabel lblNewLabel_4 = new JLabel("사는곳");
		lblNewLabel_4.setFont(new Font("배달의민족 주아", Font.PLAIN, 30));
		lblNewLabel_4.setBounds(12, 374, 159, 54);
		contentPane.add(lblNewLabel_4);
		
		JLabel lblNewLabel_5 = new JLabel("이메일");
		lblNewLabel_5.setFont(new Font("배달의민족 주아", Font.PLAIN, 30));
		lblNewLabel_5.setBounds(12, 438, 159, 54);
		contentPane.add(lblNewLabel_5);
		
		JLabel lblNewLabel_5_1 = new JLabel("성별");
		lblNewLabel_5_1.setFont(new Font("배달의민족 주아", Font.PLAIN, 30));
		lblNewLabel_5_1.setBounds(12, 502, 159, 54);
		contentPane.add(lblNewLabel_5_1);
		
		name = new JTextField();
		name.setColumns(10);
		name.setBounds(183, 195, 159, 31);
		contentPane.add(name);
		
		logn = new JTextField();
		logn.setColumns(10);
		logn.setBounds(183, 263, 159, 31);
		contentPane.add(logn);
		
		pass = new JTextField();
		pass.setColumns(10);
		pass.setBounds(183, 332, 159, 31);
		contentPane.add(pass);
		
		live = new JTextField();
		live.setColumns(10);
		live.setBounds(183, 396, 159, 31);
		contentPane.add(live);
		
		email = new JTextField();
		email.setColumns(10);
		email.setBounds(183, 460, 159, 31);
		contentPane.add(email);
		
		nick = new JTextField();
		nick.setColumns(10);
		nick.setBounds(183, 135, 159, 31);
		contentPane.add(nick);
		
		
		ButtonGroup bg = new ButtonGroup();
		
		
		JRadioButton rdbtnNewRadioButton = new JRadioButton("남");
		rdbtnNewRadioButton.setBounds(190, 523, 56, 23);
		contentPane.add(rdbtnNewRadioButton);
		
		JRadioButton rdbtnNewRadioButton_1 = new JRadioButton("여");
		rdbtnNewRadioButton_1.setBounds(267, 523, 56, 23);
		contentPane.add(rdbtnNewRadioButton_1);
	
		bg.add(rdbtnNewRadioButton);
		bg.add(rdbtnNewRadioButton_1);
		
		JButton check = new JButton("확인");
		check.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				information info = new information();
				info.setPass(pass.getText());
				info.setEmail(email.getText());
				info.setNickname(nick.getText());
				info.setLive_in(live.getText());
				info.setID(logn.getText());
				info.setName(name.getText());
				
				db.insert(info);
				
			}
		});
		check.setAction(action);
		check.setFont(new Font("배달의민족 주아", Font.PLAIN, 40));
		check.setBounds(90, 546, 212, 60);
		contentPane.add(check);
		
	}
	information in = new information();
	private class SwingAction extends AbstractAction {
		public SwingAction() {
			putValue(NAME, "확인");
			putValue(SHORT_DESCRIPTION, "Some short description");
		}
		public void actionPerformed(ActionEvent e) {
			in.setID(nick.getText());
			in.setName(name.getText());
			setVisible(false);
		}
	}
	
	
}
