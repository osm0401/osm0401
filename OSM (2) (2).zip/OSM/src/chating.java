import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import java.awt.TextArea;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.Panel;
import javax.swing.SwingConstants;
import javax.swing.ImageIcon;
import javax.swing.AbstractAction;
import java.awt.event.ActionEvent;
import javax.swing.Action;

public class chating extends JFrame {
	JPanel panel;
	JLabel pic;
	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField textField;
	private final Action action = new SwingAction();
	private final Action action_1 = new SwingAction();
	private test_client client = new test_client();

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					chating frame = new chating();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public chating() {
		client.start();
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 372, 736);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		textField = new JTextField();
		textField.setBounds(0, 599, 292, 98);
		contentPane.add(textField);
		textField.setColumns(10);
		
		JButton btnNewButton = new JButton("전송");
		btnNewButton.setAction(action_1);
		btnNewButton.setBounds(290, 599, 66, 98);
		contentPane.add(btnNewButton);
		
		JPanel panel = new JPanel();
		panel.setBounds(0, 0, 356, 598);
		contentPane.add(panel);
		panel.setLayout(null);
		
		JLabel pic = new JLabel("New label");
		pic.setIcon(new ImageIcon("C:\\Users\\bigi2\\OneDrive\\바탕 화면\\asf.png"));
		pic.setHorizontalAlignment(SwingConstants.LEFT);
		pic.setBounds(0, 0, 356, 598);
		panel.add(pic);
		
		JTextArea chating_filed = new JTextArea();
		chating_filed.setBounds(0, 0, 356, 598);
		panel.add(chating_filed);
		while(true)
		{
			if(Mylibrary.get == true)
			{
				pic.setText(textField.getText());
			}
		}
	}
	private class SwingAction extends AbstractAction {
		public SwingAction() {
			putValue(NAME, "SwingAction");
			putValue(SHORT_DESCRIPTION, "Some short description");
		}
		public void actionPerformed(ActionEvent e) {
			Mylibrary.get=true;
			Mylibrary.chat = textField.getText();
			Mylibrary.get=false;
		}
	}
}
