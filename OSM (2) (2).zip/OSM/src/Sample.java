import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.*;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class Sample {
	private final String driverName = "com.mysql.cj.jdbc.Driver";
	private final String url = "jdbc:mysql://localhost/osm?";//database이름 = testdb
	private final String user = "root";//자신의 workbench 아이디
	private final String pass = "1111";//자신의 workbench 비번
	

	PreparedStatement pstmt = null;
	Statement pt = null;
	ResultSet rs = null;
	
	public Sample(){
		//1. DB Driver를 로딩
		try {
			Class.forName(driverName);
			view();
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
	}
	
	public Connection getConnection() throws SQLException {
		//2. DB(MySQL)에 접속하기
		return DriverManager.getConnection(url, user, pass);
	}
	public boolean log_in(String nn,String ppa)
	{
		try {
    		Connection conn = getConnection();
    	
    		pstmt = conn.prepareStatement("select * from osmworld");
    		rs = pstmt.executeQuery();//select실행
    		while(rs.next())
    		{
    			String IID=(String)rs.getString("ID");
    			String PPPA=(String)rs.getString("pass");
    			if(nn.equals(IID) && ppa.equals(PPPA))
    			{
    				Mylibrary.trigger=IID;
    				return true;
    			}
    		}
    		return false;
    		/*while(rs.next()) {
    			System.out.println((rs.getString("nickname")+" "+rs.getInt("name")));
    			
    		}*/
    		}
    	catch(SQLException e)
    	{
    		
    		System.out.println(e.toString());
    		return false;
    	}
	}
	public void view()
    {
    	
    	try {
    		Connection conn = getConnection();
    	
    		pstmt = conn.prepareStatement("select * from osmworld");
    		rs = pstmt.executeQuery();//select실행
    		System.out.println("Test");
    		while(rs.next()) {
    			System.out.println((rs.getString("nickname")+" "+rs.getInt("name")));
    			
    		}
    		}
    	catch(SQLException e)
    	{
    		System.out.println(e.toString());
    	}
    }
    
    public void insert(information i)
    {
    	try {
    		Connection conn = getConnection();

    		String  sql = "INSERT INTO `osm`.`osmworld` (`nickname`, `name`, `ID`, `pass`, `live_in`, `email`) VALUES ('"+i.getID()+"', '"+i.getName()+"', '"+i.getID()+"', '"+i.getPass()+"', '"+i.getLive_in()+"','"+i.email()+"')";
    		System.out.println(sql);
    		
    		pt=conn.createStatement();
    		pt.executeUpdate(sql);
    				
    		
    		}
    	catch(SQLException e)
    	{
    		System.out.println(e.toString());
    	}
    }
    
    
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		new Sample();
	}

}
