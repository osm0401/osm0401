
public class Mylibrary {
	public static String trigger;
	public static String chat;
	public static boolean get;
}
