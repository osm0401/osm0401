
public class Mylibrary {
	public static String trigger;
	
}
